/** Automatically generated file. DO NOT MODIFY */
package com.example.ntdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}